#!/bin/bash
nic="$1-nic"
rg="$1-oxy"
for p in {1..58}
do
az network nic ip-config create -g $rg --nic-name $nic -n $1-oxy-$p --public-ip-address $1-oxy-$p
done