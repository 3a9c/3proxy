#!/bin/bash
for region in $(cat /root/clouddrive/region.txt)
do
  az group delete -n $region-oxy &
done